# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(joinReorder src/joinReorder.cpp)
set_property(TARGET joinReorder PROPERTY CXX_STANDARD 11)
target_link_libraries(joinReorder lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(fogbank src/fogbank.cpp)
set_property(TARGET fogbank PROPERTY CXX_STANDARD 11)
target_link_libraries(fogbank lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(walReplay src/walReplay.cpp)
set_property(TARGET walReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(walReplay lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(Wayfarer src/Wayfarer.cpp)
set_property(TARGET Wayfarer PROPERTY CXX_STANDARD 11)
target_link_libraries(Wayfarer lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(barnesHut src/barnesHut.cpp)
set_property(TARGET barnesHut PROPERTY CXX_STANDARD 11)
target_link_libraries(barnesHut lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(basaltedge src/basaltedge.cpp)
set_property(TARGET basaltedge PROPERTY CXX_STANDARD 11)
target_link_libraries(basaltedge lionss pthread)

add_executable(kalman-unscented src/kalman-unscented.cpp)
set_property(TARGET kalman-unscented PROPERTY CXX_STANDARD 11)
target_link_libraries(kalman-unscented lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(urdf_validate src/urdf_validate.cpp)
set_property(TARGET urdf_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(urdf_validate lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

