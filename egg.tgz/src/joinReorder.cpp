// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reorder join tree\n", stdout);
  return lionss_run_workload("joinReorder");
}
