// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate Barnes-Hut"); }
int main(){
  announce();
  return lionss_run_workload("barnesHut");
}
