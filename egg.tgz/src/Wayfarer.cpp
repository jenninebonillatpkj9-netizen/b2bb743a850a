// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Plan wayfarer route\n", stdout);
  return lionss_run_workload("Wayfarer");
}
