// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Call SNPs"); }
int main(){
  announce();
  return lionss_run_workload("snp-call");
}
