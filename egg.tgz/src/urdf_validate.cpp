// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Validate URDF tree");
  std::fflush(stdout);
  return lionss_run_workload("urdf_validate");
}
