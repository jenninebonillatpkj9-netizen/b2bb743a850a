// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate edge rules"); }
int main(){
  announce();
  return lionss_run_workload("basaltedge");
}
